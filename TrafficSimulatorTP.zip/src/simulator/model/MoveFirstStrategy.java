package simulator.model;

import java.util.ArrayList;
import java.util.List;

public class MoveFirstStrategy implements DequeuingStrategy{

	//Devuelvo una lista con el primer elemento de q
	
	@Override
	public List<Vehicle> dequeue(List<Vehicle> q) {
		List<Vehicle> m=new ArrayList<Vehicle>();
		if(!q.isEmpty())
		{
			m.add(q.get(0));
		}
			
		return m;
	}
}
