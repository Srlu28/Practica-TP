package simulator.model;

import org.json.JSONObject;

import simulator.misc.SortedArrayList;

public class TrafficSimulator {

	//Atributos
	
	private RoadMap _mapaCarreteras;
	private SortedArrayList<Event> _listaEventos;
	private int _tiempo;
	
	//Constructor
	
	public TrafficSimulator()
	{
		this._mapaCarreteras=new RoadMap();
		this._listaEventos=new SortedArrayList<Event>();
		this._tiempo=0;
	}
	
	//Metodos a desarrollar
	
	public void addEvent(Event e)
	{
		this._listaEventos.add(e);
	}
	
	public void advance()
	{
		//Aumenta el tiempo de la simulacion en 1
		this._tiempo++;
		
		//Ejecutamos los eventos, hay que tener en cuenta que devolvemos una lista que es una copia por ello la original no la podemos borrar
		SortedArrayList<Event> aux = new SortedArrayList<Event>();
		for(Event ev:this._listaEventos)
		{
			if(ev._time==this._tiempo) {
				ev.execute(_mapaCarreteras);
			}
			else aux.add(ev);
		}
		this._listaEventos=aux;		
		
		//Llamamos al metodo de advanceJunction
		this._mapaCarreteras.advanceJunction(this._tiempo);
		//Llamamos al metodo de advanceRoad
		this._mapaCarreteras.advanceRoad(this._tiempo);
		
	}
	
	public void reset()
	{
		this._mapaCarreteras.reset();
		this._listaEventos.clear();
		this._tiempo=0;
	}
	
	public JSONObject report()
	{
		JSONObject jo1=new JSONObject();
		jo1.put("time", this._tiempo);
		JSONObject jo2 = new JSONObject();
		jo2 = this._mapaCarreteras.report();
		jo1.put("state", jo2 );
		
		return jo1;
	}

}
