package simulator.model;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import Excepciones.Atributos.AtributoException;
import Excepciones.Junction.AddingRoadException;
import Excepciones.Junction.JunctionConstructorException;

public class Junction extends SimulatedObject{
	
	//Atributos
	
	private List<Road> _CarreterasEntrantes;
	private Map<Junction,Road> _CarreterasSalientes;
	private ArrayList<List<Vehicle>> _ListaColas;
	private Map<Road,List<Vehicle>> _MapaCarreteraCola;
	private int _semaforoVerde;
	private int _lastSwicthingtime;
	private LightSwitchingStrategy _ls;
	private DequeuingStrategy _dq;
	private int _x,_y;

	Junction(String id,LightSwitchingStrategy ls,DequeuingStrategy dq,int x, int y) throws JunctionConstructorException {
		super(id);
		if(dq != null && ls !=null && x>=0 && y>=0)
		{
			this._dq=dq;
			this._ls=ls;
			this._x=x;
			this._y=y;
			this._CarreterasEntrantes=new ArrayList<Road>();
			this._ListaColas=new ArrayList<List<Vehicle>>();
			this._CarreterasSalientes=new HashMap<Junction,Road>();
			this._MapaCarreteraCola=new HashMap<Road,List<Vehicle>>();
			this._semaforoVerde=-1;
			this._lastSwicthingtime=0;
		}
		else throw new JunctionConstructorException("Cannot create Junction");
	}
	
	//Metodos a desarrollar
	
	void addIncomingRoad(Road r) throws AddingRoadException
	{
		if(r.getDesJunc().equals(this))
		{
			this._CarreterasEntrantes.add(r);
			ArrayList<Vehicle> queue=new ArrayList<Vehicle>();
			this._ListaColas.add(queue);
			this._MapaCarreteraCola.put(r, queue);
		}
		else throw new AddingRoadException("This road isn't an IncomingRoad");
	}
	
	void addOutGoingRoad(Road r) throws AddingRoadException
	{
		Junction j=r.getDesJunc();
		if(this._CarreterasSalientes.containsKey(j) || j==this) throw new AddingRoadException(); //Comprobar que no hay carreteras que van al cruce j
		else this._CarreterasSalientes.put(j, r);
		
	}
	
	void enter(Vehicle v)
	{
		Road r=v.getRoad();
		this._MapaCarreteraCola.get(r).add(v);
	}
	
	Road roadTo(Junction j)
	{
		return this._CarreterasSalientes.get(j);
	}

	Boolean containsCarreteraSaliente(Junction j)
	{
		return this._CarreterasSalientes.containsKey(j);
	}
	
	@Override
	void advance(int time) {
		//Estrategia de extraccion de colas
		if(this._semaforoVerde!=-1)
		{
			//Pregunto que carretera pone su semaforo en verde y cuantos coches han de cambiar de carretera
			List<Vehicle> l1=this._ListaColas.get(_semaforoVerde);
			List<Vehicle> cochesAfectados=this._dq.dequeue(l1);
			
			for(Vehicle v: cochesAfectados)
			{
				try {
					v.moveToNextRoad();
					l1.remove(v);
				} catch (AtributoException e) {
					System.out.println(e.getMessage());
				}//Los coches se mueven, por ende se cambia de carretera
				this._ListaColas.set(this._semaforoVerde, l1);//Actualizamos la lista de colas
			}
		}
		//Estrategia de cambio de semaforo
		int nuevoVerde=_ls.chooseNextGreen(this._CarreterasEntrantes, this._ListaColas, _semaforoVerde, this._lastSwicthingtime, time);
		if(nuevoVerde != this._semaforoVerde)
		{
			this._semaforoVerde=nuevoVerde;
			this._lastSwicthingtime=time;
		}
	}

	@Override
	public JSONObject report() {
		JSONObject jo1=new JSONObject();
		JSONArray ja = new JSONArray();
		jo1.put("id", this._id);
		if(this._semaforoVerde ==-1)
		{
			jo1.put("green", "none");
		}
		else
			jo1.put("green", this._CarreterasEntrantes.get(this._semaforoVerde).getId());
		for(Road road : this._CarreterasEntrantes)
		{
			JSONObject jo=new JSONObject();
			jo.put("road", road.getId());
			JSONArray ja1=new JSONArray();
			for(Vehicle v : this._MapaCarreteraCola.get(road))
				ja1.put(v._id);
			jo.put("vehicles", ja1);
			ja.put(jo);
		}
		jo1.put("queues", ja);
		return jo1;
	}
	
}
