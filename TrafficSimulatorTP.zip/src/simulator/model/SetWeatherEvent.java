package simulator.model;

import java.util.List;

import Excepciones.Atributos.AtributoException;
import Excepciones.Atributos.EventBuildExcep;
import Excepciones.Map.MapException;
import simulator.misc.Pair;

public class SetWeatherEvent extends Event{
	
	//Atributos
	
	List<Pair<String,Weather>> _ws;
	
	//Constructor
	
	public SetWeatherEvent(int time,List<Pair<String,Weather>> ws) throws EventBuildExcep {
		super(time);
		if(ws !=null) _ws=ws;
		else {
			throw new EventBuildExcep("ws cannot be null");
		}
	}
	
	@Override
	void execute(RoadMap map) {
		for(Pair<String,Weather> w:this._ws)
		{
			try
			{
				addRoad(w,map);
			}catch(MapException e)
			{
				e.printStackTrace();
			}
		}
	}

	//Con este metodo modificamos las condiciones atmosf�ricas de la carretera
	
	private void addRoad(Pair<String,Weather> w,RoadMap map)throws MapException
	{
		String id= w.getFirst();
		Weather we= w.getSecond();
		Road road=map.getRoad(id);
		if(road !=null) {
			try {
				road.setWeather(we);
			} catch (AtributoException e) {
				e.printStackTrace();
			}
		}
		else throw new MapException("Inexistent Road");
	}
	
}
