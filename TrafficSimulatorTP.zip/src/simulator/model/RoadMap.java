package simulator.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import Excepciones.Map.MapException;

public class RoadMap{
	
	//Atributos
	
	private List<Junction> _ListaCruces;
	private List<Road> _ListaCarreteras;
	private List<Vehicle> _ListaVehiculos;
	private Map<String,Junction> _MapaCruces;
	private Map<String,Road> _MapaCarretera;
	private Map<String,Vehicle> _MapaVehiculos;
	
	//Constructora
	
	RoadMap()
	{
		this._ListaCruces=new ArrayList<Junction>();
		this._MapaCruces=new HashMap<String,Junction>();
		this._ListaCarreteras=new ArrayList<Road>();
		this._MapaCarretera=new HashMap<String,Road>();
		this._MapaVehiculos=new HashMap<String,Vehicle>();
		this._ListaVehiculos=new ArrayList<Vehicle>();
	}
	
	//Metodos a desarrollar 
	
	void addJunction(Junction j) throws MapException
	{
		Junction aux=this._MapaCruces.put(j.getId(), j);
		if(aux != null) throw new MapException("Cannot add this junction, already exists");
		this._ListaCruces.add(j);
	}
	
	void addRoad(Road r) throws MapException
	{
		Road aux=this._MapaCarretera.put(r.getId(), r);
		if(aux !=null) throw new MapException("Cannot add this road, already exists");
		else if(!this._MapaCruces.containsValue(r.getDesJunc()) ||!this._MapaCruces.containsValue(r.getOriJun()))
				throw new MapException("Cannot add this road,these junctions doesn't exist in the road map");
		this._ListaCarreteras.add(r);
	}
	
	void addVehicle(Vehicle v) throws MapException
	{
		Vehicle aux=this._MapaVehiculos.put(v.getId(), v);
		if(aux != null || !checkItinerary(v) )
		{
			throw new MapException("Cannot add this vehicle");
		}
		this._ListaVehiculos.add(v);
	}
	
	public void reset()
	{
		this._MapaCarretera.clear();
		this._MapaCruces.clear();
		this._MapaVehiculos.clear();
		this._ListaCruces.clear();
		this._ListaCarreteras.clear();
		this._ListaVehiculos.clear();
	}
	
	public JSONObject report()
	{
		JSONObject obj1=new JSONObject();
		JSONArray ja1=new JSONArray();
		for(Junction j : this._ListaCruces)
		{
			ja1.put(j.report());
		}
		obj1.put("junctions",ja1);
		JSONArray ja2=new JSONArray();
		for(Road r : this._ListaCarreteras)
		{
			ja2.put(r.report());
		}
		obj1.put("roads", ja2);
		JSONArray ja3=new JSONArray();
		for(Vehicle v : this._ListaVehiculos)
		{
			ja3.put(v.report());
		}
		obj1.put("vehicles",ja3);
		return obj1;
	}
	
	private boolean checkItinerary(Vehicle v) //Comprobamos si el coche tiene un itinerario adecuado al mapa de carreteras
	{
		List<Junction> itinerario=v.getItinerario();
		Junction ori,des;
		boolean ok=true;
		
		if(!itinerario.isEmpty())
		{
			ori=itinerario.get(0);
			int i=0;
			while(i<itinerario.size()-1 && ok)
			{
				int j=i+1;
				des=itinerario.get(j);
				ok &= ori.containsCarreteraSaliente(des);
				ori=des;
				i++;
			}
		}
		return ok;
	}
	
	void advanceRoad(int time)
	{
		for(Road r : this._ListaCarreteras)
				r.advance(time);
	}
	
	void advanceJunction(int time)
	{
		for(Junction j:this._ListaCruces) 
			j.advance(time);
	}
	
	//GETTERS
	
	public Junction getJunction(String id)
	{
		return this._MapaCruces.get(id);
	}
	
	public Road getRoad(String id)
	{
		return this._MapaCarretera.get(id);
	}
	
	public Vehicle getVehicle(String id)
	{
		return this._MapaVehiculos.get(id);
	}
	
	public List<Junction> getJunctions()
	{
		return Collections.unmodifiableList(new ArrayList <>(this._ListaCruces));
	}
	
	public List<Vehicle> getVehicles()
	{
		return Collections.unmodifiableList(new ArrayList <>(this._ListaVehiculos));
	}
	
}
