package simulator.model;

import java.util.List;

public class MostCrowdedStrategy implements LightSwitchingStrategy{
	
	//Atributos

	int timeSlot;
	
	//Constructor
	
	public MostCrowdedStrategy(int timeSlot) {
		this.timeSlot=timeSlot;
	}
	
	@Override
	public int chooseNextGreen(List<Road> roads, List<List<Vehicle>> qs, int currGreen, int lastSwitchingTime,
			int currTime) {
		if(roads.isEmpty())return -1;
		
		else if(currTime-lastSwitchingTime <timeSlot)return currGreen;
		
		else if(currGreen ==-1) return ListaMasLarga(qs,0);
		
		else return ListaMasLarga(qs, (currGreen+1)%roads.size());
	}
	
	private int ListaMasLarga(List<List<Vehicle>> qs, int pos) {
		int indice=0,max=0;
		for(int i=pos;i<qs.size();i++)
		{
			if(max<qs.get(i).size()) 
			{
				indice=i;
				max=qs.get(i).size();
			}
		}
		for(int i=0 ; i<pos;i++)
		{
			if(max<qs.get(i).size()) 
			{
				indice=i;
				max=qs.get(i).size();
			}
		}
		return indice;
	}

}
