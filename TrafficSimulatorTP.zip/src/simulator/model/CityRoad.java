package simulator.model;

import Excepciones.Road.RoadConstructorException;

public class CityRoad extends Road{

	//Constructor
	
	CityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int lenght, Weather weather)
			throws RoadConstructorException {
		super(id, srcJunc, destJunc, maxSpeed, contLimit, lenght, weather);
	}

	@Override
	void reduceTotalContamination() {
		int x;
		if(this.getWeather()==Weather.WINDY || this.getWeather()==Weather.STORM)x=10;
		else x=2;
		
		this.lessContamination(x);
	}

	@Override
	void updateSpeedLimit() {
	}

	@Override
	int calculateVehicleSpeed(Vehicle v) {
		int f=v.getContClass();
		int s=this.getLimit();
		int res=(int) Math.ceil((((11.0-f)/11.0)*s)); //Usamos MathCeil porque si no en vez de 88 pone 87 como distancia calculada, de esta manera queda correcto
		return res;
	}
}
