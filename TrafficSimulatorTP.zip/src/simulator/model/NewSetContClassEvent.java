package simulator.model;

import java.util.List;

import Excepciones.Atributos.EventBuildExcep;
import Excepciones.Map.MapException;
import Excepciones.Vehicle.VehicleContClassException;
import simulator.misc.Pair;

public class NewSetContClassEvent extends Event{
	
	//Atributos
	
	List<Pair<String,Integer>> _cs;
	
	//Constructor
	
	public NewSetContClassEvent(int time,List<Pair<String,Integer>> cs) throws EventBuildExcep {
		super(time);
		if(cs!=null)_cs=cs;
		else
		{
			throw new EventBuildExcep("Invalid data");
		}
	}

	@Override
	void execute(RoadMap map) {
		for(Pair<String , Integer> c:this._cs)
		{
			try
			{
				addVehicle(c,map);
			}catch(MapException e)
			{
				e.printStackTrace();
			}
		}
	}

	void addVehicle(Pair<String , Integer> c,RoadMap map)throws MapException
	{
		String id= c.getFirst();
		int cont= c.getSecond();
		Vehicle v=map.getVehicle(id);
		if(v !=null) {
			try {
				v.setContaminationClass(cont);
			} catch (VehicleContClassException e) {
				e.printStackTrace();
			}
		}
		else throw new MapException("Inexistent Road");
	}
}
