package simulator.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import Excepciones.Atributos.AtributoException;
import Excepciones.Junction.AddingRoadException;
import Excepciones.Road.RoadConstructorException;
import Excepciones.Road.enterVehicleException;
import Excepciones.Vehicle.VehicleSpeedException;
import simulator.misc.SortedArrayList;

public abstract class Road extends SimulatedObject{
	
	//Atributos
	
	private Junction _origJunc,_destJunc;
	private int _longitud;
	private int _maxVeloc;
	private int _limVeloc;
	private int _alarmCO2;
	private Weather _tiempo;
	private SortedArrayList<Vehicle> _vehiculos; //Ordenada segun localizacion
	private int _totalCO2;

	//Constructor
	
	Road(String id,Junction srcJunc,Junction destJunc, int maxSpeed, int contLimit, int lenght, Weather weather) throws RoadConstructorException {
		super(id);
		if(maxSpeed > 0 && contLimit>=0 && lenght > 0 && srcJunc != null && destJunc !=null) 
		{
			this._origJunc=srcJunc;
			this._destJunc=destJunc;
			this._maxVeloc=maxSpeed;
			this._alarmCO2=contLimit;
			this._longitud=lenght;
			this._tiempo=weather;
			this._totalCO2=0;
			this._limVeloc=maxSpeed;
			this._vehiculos=new SortedArrayList<Vehicle>();
			try {
				this._destJunc.addIncomingRoad(this);
				this._origJunc.addOutGoingRoad(this);
			}catch(AddingRoadException e)
			{
				System.out.println(e.getMessage());
			}
		}
		else throw new RoadConstructorException("Unable to create the Road Object");
	}

	
	@Override
	void advance(int time) {
		reduceTotalContamination();
		
		updateSpeedLimit();
		
		for(Vehicle v:this._vehiculos)
		{
			try {
				int s=this.calculateVehicleSpeed(v);
				v.setSpeed(s);
				v.advance(time);
			}catch(VehicleSpeedException e)
			{
				System.out.println(e.getMessage());
			}
		}
	}
	

	@Override
	public JSONObject report() {
		JSONObject jo1=new JSONObject();
		jo1.put("id", this._id);
		jo1.put("speedlimit", this._limVeloc);
		jo1.put("weather", this._tiempo);
		jo1.put("co2", this._totalCO2);
		JSONArray ja=new JSONArray();
		for(Vehicle v:this._vehiculos)
		{
			ja.put(v.getId());
		}
		jo1.put("vehicles", ja);
		
		return jo1;
	}
	
	//Metodos a desarrollar
	
	void enter(Vehicle v) throws enterVehicleException
	{
		if(v.getLoc()==0 && v.currentSpeed()==0) this._vehiculos.add(v);
		else throw new enterVehicleException("Unable to enter the vehicle " + v.getId() + "on the road "+ this._id);
	}
	
	void exit(Vehicle v)
	{
		this._vehiculos.remove(v);
	}
	
	void setWeather(Weather w) throws AtributoException
	{
		if(w==null)throw new AtributoException("Weather cannot be null");
		else this._tiempo=w;
	}
	
	void addContamination(int c) throws AtributoException 
	{
		if(c>=0)
			this._totalCO2+=c;
		else throw new AtributoException("Pollution cannot be negative");
	}
	
	public void lessContamination(int c)
	{
		this._totalCO2-=c;
		if(this._totalCO2<0)this._totalCO2=0;
	}
	
	abstract void reduceTotalContamination();
	abstract void updateSpeedLimit();
	abstract int calculateVehicleSpeed(Vehicle v);
	
	//GETTERS Y SETTERS
	
	public int getCO2()
	{
		return this._totalCO2;
	}
	
	public void setCO2(int c)
	{
		this._totalCO2=c;
	}
	
	ArrayList<Vehicle> getVehiculos()
	{
		return new ArrayList<Vehicle>(this._vehiculos);
	}
	
	public int getMaxVeloc()
	{
		return this._maxVeloc;
	}
	
	public void setLimit(int s)
	{
		this._limVeloc=s;
	}
	
	public int getLong() {
		return this._longitud;
	}

	public int getLimit() {
		return this._limVeloc;
	}

	public Junction getOriJun() {
		return this._origJunc;
	}

	public Junction getDesJunc() {
		return this._destJunc;
	}

	public int getAlarma() {
		return this._alarmCO2;
	}
	
	public Weather getWeather()
	{
		return this._tiempo;
	}
}
