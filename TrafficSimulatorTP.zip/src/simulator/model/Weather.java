package simulator.model;

public enum Weather {
	SUNNY(2), CLOUDY(3), RAINY(10), WINDY(15), STORM(20);
	private int condition;
	
	Weather(int con)
	{
		this.condition=con;
	}
	
	public int getCondition()
	{
		return condition;
	}
}
