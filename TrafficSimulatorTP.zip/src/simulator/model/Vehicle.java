package simulator.model;

import java.util.List;

import org.json.JSONObject;

import Excepciones.Atributos.AtributoException;
import Excepciones.Road.enterVehicleException;
import Excepciones.Vehicle.VehicleConstructorException;
import Excepciones.Vehicle.VehicleContClassException;
import Excepciones.Vehicle.VehicleSpeedException;

import java.util.ArrayList;
import java.util.Collections;

public class Vehicle extends SimulatedObject implements Comparable<Vehicle>{
	
	//Atributos
	
	private List<Junction> _itinerario;
	private int _maxVelocidad;
	private int _velocidadActual;
	private VehicleStatus _estado;
	private Road _road;
	private int _loc;
	private int _gradoCO2;
	private int _totalCO2;
	private int _totalDistancia;
	private int _index;
	
	//Constructor
	
	Vehicle(String id,List<Junction> itinerary,int maxSpeed, int contClass) throws VehicleConstructorException {
		super(id);
		if(maxSpeed > 0 && 0<=contClass && contClass <=10 && itinerary.size()>=2)
		{
			this._itinerario=Collections.unmodifiableList(new ArrayList<>(itinerary));
			this._gradoCO2=contClass;
			this._maxVelocidad=maxSpeed;
			this._loc=0;
			this._velocidadActual=0;
			this._estado=VehicleStatus.PENDING;
			this._road=null;
			this._totalCO2=0;
			this._totalDistancia=0;
			this._index=0;
		}
		else throw new VehicleConstructorException("Failed to create the Vehicle.");
	}

	@Override
	void advance(int time) {
		if(this._estado == VehicleStatus.TRAVELING) //Si no es advance no hago nada
		{
				try {
					//Actualiza la localizacion
					int old=this._loc;
					this._loc=Math.min(_loc+this._velocidadActual, this._road.getLong());
					this._totalDistancia+=this._loc-old;
					
					//Calcula la contaminacion
					int co2Prod=this._gradoCO2*(this._loc-old);
					this._totalCO2+=co2Prod;
					this._road.addContamination(co2Prod);
					
					//Comprobamos en que punto de la carretera esta
					if(_loc>=_road.getLong())
					{
						this._velocidadActual=0;
						this._estado=VehicleStatus.WAITING;//Ponemos el vehiculo a waiting y lo metemos en la cola del cruce correspondiente
						Junction j=this._road.getDesJunc();
						j.enter(this);
					}
				} catch (AtributoException e) {
					System.out.println(e.getMessage());
				}
		}
	}
	
	void moveToNextRoad() throws AtributoException{
		//Solo hacemos este metodo si estamos esperando a cruzar o a empezar el recorrido
		if(this._estado != VehicleStatus.WAITING && this._estado != VehicleStatus.PENDING) throw new AtributoException("Unable to move a non pending/waiting vehicle");
		else
		{
			//Depende del estado del vehiculo haremos una cosa u otra
			if(this._estado==VehicleStatus.WAITING)_road.exit(this);
			
			if(this._index==this._itinerario.size()-1) {
				_estado=VehicleStatus.ARRIVED;//El vehiculo ha completado su trayectoria
				this._velocidadActual=0;
			}
			else//Si aun tiene camino por recorrer
			{
				try {
					this._estado=VehicleStatus.TRAVELING;
					int j=this._index+1;
					this._loc=0;
					Junction j1=_itinerario.get(_index);
					Junction j2=_itinerario.get(j);
					_index++;
					this._road=j1.roadTo(j2);//Ahora la carretera es la que va del cruce en el que estabamos al cruce siguiente
					_road.enter(this);//Metemos el vehiculo en dicha carretera
				}catch(enterVehicleException e)
				{
					System.out.println(e.getMessage());
				}
			}
		}
	}

	@Override
	public JSONObject report() {
		JSONObject jo1=new JSONObject();
		jo1.put("id", _id);
		jo1.put("speed", this._velocidadActual);
		jo1.put("distance", this._totalDistancia);
		jo1.put("co2", this._totalCO2);
		jo1.put("class", this._gradoCO2);
		jo1.put("status", this._estado);
		if(this._estado != VehicleStatus.PENDING && this._estado != VehicleStatus.ARRIVED)
		{
			jo1.put("road", _road);
			jo1.put("location", _loc);
		}
		return jo1;
	}
	
	//Getters y setters
	
	void setSpeed(int s) throws VehicleSpeedException
	{
		if(this._estado != VehicleStatus.ARRIVED && this._estado != VehicleStatus.WAITING)
		{
			if(s<0)throw new VehicleSpeedException("Vehicle's speed cannot be negative");
			this._velocidadActual=Math.min(s, this._maxVelocidad);
		}
		
	}
	
	void setContaminationClass(int c) throws VehicleContClassException
	{
		if(0<=c && c<=10) this._gradoCO2=c;
		else throw new VehicleContClassException("Invalid contamination class");
	}
	
	List<Junction> getItinerario()
	{
		return Collections.unmodifiableList(new ArrayList<>(this._itinerario));
	}
	
	Road getRoad()
	{
		return this._road;
	}
	
	int maxSpeed()
	{
		return this._maxVelocidad;
	}
	
	int currentSpeed()
	{
		return this._velocidadActual;
	}
	
	VehicleStatus getStatus()
	{
		return this._estado;
	}
	
	int getLoc()
	{
		return this._loc;
	}
	
	int getContClass()
	{
		return this._gradoCO2;
	}
	
	int getTotalCont()
	{
		return this._totalCO2;
	}
	
	int getDist()
	{
		return this._totalDistancia;
	}

	@Override
	public int compareTo(Vehicle o) {
		if(o._loc == this._loc) return 0;
		if(this._loc<o._loc) return 1;
		else return -1;
	}
}
