package simulator.model;

import java.util.ArrayList;
import java.util.List;

public class MoveAllStrategy implements DequeuingStrategy{

	//Devuelvo una lista igual que q pero no la misma
	
	@Override
	public List<Vehicle> dequeue(List<Vehicle> q) {
		List<Vehicle> m=new ArrayList<Vehicle>(q);
		return m;
	}

}

