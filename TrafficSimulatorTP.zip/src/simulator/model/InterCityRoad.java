package simulator.model;

import Excepciones.Road.RoadConstructorException;

public final class InterCityRoad extends Road{

	//Constructor 
	
	InterCityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int lenght,
			Weather weather) throws RoadConstructorException {
		super(id, srcJunc, destJunc, maxSpeed, contLimit, lenght, weather);
	}

	@Override
	void reduceTotalContamination() {
		int x=this.getWeather().getCondition();
		int tc=this.getCO2();
		int res=(int)(((100.0-x)/100.0)*tc);
		this.setCO2(res);
	}

	@Override
	void updateSpeedLimit() {
		int nSpeed;
		if(this.getCO2()>this.getAlarma())
		{
			nSpeed=(int)(this.getMaxVeloc()*0.5);
			this.setLimit(nSpeed);
		}
		else this.setLimit(this.getMaxVeloc());
		
	}

	@Override
	int calculateVehicleSpeed(Vehicle v) {
		if(this.getWeather() ==Weather.STORM)
		{
			int res=(int) (this.getLimit()*0.8);
			return res;
		}
		else return this.getLimit();
	}

}
