package simulator.model;

import Excepciones.Junction.JunctionConstructorException;
import Excepciones.Map.MapException;

public  class NewJunctionEvent extends Event  {
	Junction _junc;
	String _id;
	LightSwitchingStrategy _lsStrategy;
	DequeuingStrategy _dqStrategy; 
	int _xCoor, _yCoor;
	public NewJunctionEvent(int time,String id,LightSwitchingStrategy lsStrategy,DequeuingStrategy dqStrategy, int xCoor, int yCoor)
	{
		super(time);
		this._id=id;
		this._lsStrategy=lsStrategy;
		this._dqStrategy=dqStrategy;
		this._xCoor=xCoor;
		this._yCoor=yCoor;
	}

	@Override
	void execute(RoadMap map) {
		try {
			_junc=new Junction(_id,_lsStrategy,_dqStrategy,_xCoor,_yCoor);
			map.addJunction(this._junc);
		} catch (JunctionConstructorException | MapException  e) {
			e.printStackTrace();
		}
	}
	
}
