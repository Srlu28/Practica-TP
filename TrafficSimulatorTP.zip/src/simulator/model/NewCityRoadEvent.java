package simulator.model;

import Excepciones.Map.MapException;
import Excepciones.Road.RoadConstructorException;

public class NewCityRoadEvent extends Event{
	
	//Atributos
	
	String _id,_oriJun,_desJunc;
	int _long,_co2Limit,_maxVeloc;
	Weather _tiempo;
	
	//Constructores
	
	public NewCityRoadEvent(int time,String id,String srcJun,String desJunc, int lenght, int co2Limit, int maxSpeed,Weather weather)
	{
		super(time);
		this._oriJun=srcJun;
		this._desJunc=desJunc;
		this._long=lenght;
		this._co2Limit=co2Limit;
		this._maxVeloc=maxSpeed;
		this._tiempo=weather;
		this._id=id;
	}

	@Override
	void execute(RoadMap map) {
		Junction srcJun,desJunc;
		srcJun=map.getJunction(this._oriJun);
		desJunc=map.getJunction(this._desJunc);
		try {
			Road cityR=new CityRoad(_id,srcJun,desJunc,_maxVeloc,_co2Limit,_long,_tiempo);
			map.addRoad(cityR);
		} catch (RoadConstructorException | MapException e) {
			e.printStackTrace();
		} 
	}
}
