package simulator.model;

import java.util.ArrayList;
import java.util.List;

import Excepciones.Atributos.AtributoException;
import Excepciones.Map.MapException;
import Excepciones.Vehicle.VehicleConstructorException;



public class NewVehicleEvent extends Event{
	
	//Atributo
	
	int _gradoCO2,_maxVeloc;
	String _id;
	List<String> _itinerario;

	//Constructor
	
	public NewVehicleEvent(int time,String id,int maxSpeed, int contClass,List<String> itinerary) {
		super(time);
		this._id=id;
		this._maxVeloc=maxSpeed;
		this._gradoCO2=contClass;
		this._itinerario=itinerary;
	}

	@Override
	void execute(RoadMap map) {
		// TODO Auto-generated method stub
		List<Junction> itinerary=createItinerary(map);
		try {
			Vehicle v=new Vehicle(_id,itinerary,_maxVeloc,_gradoCO2);
			map.addVehicle(v);
			v.moveToNextRoad();
		} catch (VehicleConstructorException | MapException |AtributoException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Parseamos el itinerario de String a junction
	
	private List<Junction> createItinerary(RoadMap map)
	{
		List<Junction> list = new ArrayList<Junction>(); ;
		for(String id:this._itinerario)
		{
			Junction jun=map.getJunction(id);
			list.add(jun);
		}
		return list;
	}

}
