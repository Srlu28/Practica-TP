package simulator.control;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import Excepciones.Atributos.AtributoException;
import Excepciones.Atributos.LoadException;
import simulator.factories.Factory;
import simulator.model.Event;
import simulator.model.TrafficSimulator;

public class Controller {
	
	//Atributos
	
	private TrafficSimulator _simulador;
	private Factory<Event> _factEventos;
	
	//Constructor
	
	public Controller(TrafficSimulator sim,Factory<Event> eventsFactory) throws AtributoException
	{
		if(sim ==null || eventsFactory ==null) throw new  AtributoException();
		else {

			this._simulador=sim;
			this._factEventos=eventsFactory;
			
		}
	}
	
	//Metodos a desarrollar
	
	public void loadEvents(InputStream in) throws LoadException
	{
		try
		{
			JSONObject jo=new JSONObject(new JSONTokener(in));
			JSONArray ja=jo.getJSONArray("events");
			for(int i=0;i<ja.length();i++)
			{
				JSONObject jo1=ja.getJSONObject(i);
				Event ev=this._factEventos.createInstance(jo1);
				this._simulador.addEvent(ev);
				
			}
		}
		catch(JSONException e)
		{
			throw new LoadException("Unable to Load the events");
		}
	}
	
	public void run(int n, OutputStream out)
	{
		JSONArray ja=new JSONArray();
		for(int i=0;i<n;i++)
		{
			this._simulador.advance();
			JSONObject s=this._simulador.report();
			ja.put(s);
			
		}
		JSONObject jo1=new JSONObject();
		jo1.put("states", ja);
		PrintStream cout=new PrintStream(out);
		cout.println(jo1.toString(3));
	}
	
	public void reset()
	{
		this._simulador.reset();
	}
	
}
