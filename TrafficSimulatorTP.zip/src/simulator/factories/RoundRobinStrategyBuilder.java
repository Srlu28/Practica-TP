package simulator.factories;

import org.json.JSONObject;

import simulator.model.LightSwitchingStrategy;
import simulator.model.RoundRobinStrategy;

public class RoundRobinStrategyBuilder extends Builder<LightSwitchingStrategy>{

	private static String name= "round_robin_lss";
	
	public RoundRobinStrategyBuilder() {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected LightSwitchingStrategy createTheInstance(JSONObject data) {
		// TODO Auto-generated method stub
		return data.has(timeslot) ? new RoundRobinStrategy(data.getInt(timeslot)): new RoundRobinStrategy(1);
	}

}
