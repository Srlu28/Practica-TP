package simulator.factories;

import org.json.JSONObject;

import simulator.model.LightSwitchingStrategy;
import simulator.model.MostCrowdedStrategy;


public class MostCrowdedStrategyBuilder extends Builder<LightSwitchingStrategy>{

	static String name="most_crowded_lss";
	public MostCrowdedStrategyBuilder() {
		super(name);
		
	}
	@Override
	protected LightSwitchingStrategy createTheInstance(JSONObject data) {
		return data.has(timeslot) ? new MostCrowdedStrategy(data.getInt(timeslot)): new MostCrowdedStrategy(1);
	}
	
}