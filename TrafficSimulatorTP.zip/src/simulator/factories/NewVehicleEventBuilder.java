package simulator.factories;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import simulator.model.Event;
import simulator.model.NewVehicleEvent;

public class NewVehicleEventBuilder extends Builder<Event>{
	
	public static String name="new_vehicle";
	
	public NewVehicleEventBuilder() {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Event createTheInstance(JSONObject data) {
		try
		{
			int time=data.getInt("time");
			String id=data.getString("id");
			int maxSpeed=data.getInt("maxspeed");
			int clase=data.getInt("class");
			JSONArray j=data.getJSONArray("itinerary");
			ArrayList<String> l=setString(j);
			Event ev=new NewVehicleEvent(time,id,maxSpeed,clase,l);
			return ev;
		}
		catch(JSONException e)
		{
			e.printStackTrace();
			return null;
		}
	}
	private ArrayList<String> setString(JSONArray j) throws JSONException
	{
		ArrayList<String> l=new ArrayList<String>();
		for(int i=0;i<j.length();i++)
		{
			l.add(j.getString(i));
		}
		return l;
	}
}
