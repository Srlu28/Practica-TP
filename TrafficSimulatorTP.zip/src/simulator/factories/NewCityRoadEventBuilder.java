package simulator.factories;

import org.json.JSONException;
import org.json.JSONObject;

import simulator.model.Event;

import simulator.model.NewCityRoadEvent;
import simulator.model.Weather;

public class NewCityRoadEventBuilder extends Builder<Event>{
	
	private static String name="new_city_road";

	public NewCityRoadEventBuilder() {
		super(name);
		// TODO Auto-generated constructor stub
	}
	@Override
	protected Event createTheInstance(JSONObject data) {
		try {
			int time=data.getInt("time");
			String id=data.getString("id");
			String jun1=data.getString("src");
			String jun2=data.getString("dest");
			int lenght=data.getInt("length");
			int co2limit=data.getInt("co2limit");
			int maxspeed=data.getInt("maxspeed");
			String w=data.getString("weather");
			Weather we=Weather.valueOf(w);
			
			Event ev=new NewCityRoadEvent(time,id,jun1,jun2,lenght,co2limit,maxspeed,we);
			return ev;
		}catch(JSONException e){
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	

}
