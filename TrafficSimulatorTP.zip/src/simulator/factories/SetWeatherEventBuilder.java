package simulator.factories;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import Excepciones.Atributos.EventBuildExcep;
import simulator.misc.Pair;
import simulator.model.Event;
import simulator.model.SetWeatherEvent;
import simulator.model.Weather;

public class SetWeatherEventBuilder extends Builder<Event>{
 
	private static String name="set_weather";
	
	public SetWeatherEventBuilder() {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Event createTheInstance(JSONObject data) {
		try
		{
			Event ev;
			int time=data.getInt("time");
			JSONArray j=data.getJSONArray("info");
			List<Pair<String,Weather>> l=getList(j);
			ev= new SetWeatherEvent(time,l);
			return ev;
		}
		catch(JSONException | EventBuildExcep e)
		{
			e.printStackTrace();
			return null;
		}
	}

	private List<Pair<String, Weather>> getList(JSONArray j) throws JSONException {
		List<Pair<String, Weather>> l=new ArrayList<Pair<String,Weather>>();
		for(int i=0;i<j.length();i++)
		{
			JSONObject j1=j.getJSONObject(i);
			String name=j1.getString("road");
			Weather we=Weather.valueOf(j1.getString("weather"));
			Pair<String,Weather> pair=new Pair<String,Weather>(name,we);
			l.add(pair);
		}
		return l;
	}

}
