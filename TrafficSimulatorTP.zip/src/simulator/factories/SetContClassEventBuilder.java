package simulator.factories;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import Excepciones.Atributos.EventBuildExcep;
import simulator.misc.Pair;
import simulator.model.Event;
import simulator.model.NewSetContClassEvent;

public class SetContClassEventBuilder extends Builder<Event>{

	private static String name="set_cont_class";
	public SetContClassEventBuilder() {
		super(name);
	}

	@Override
	protected Event createTheInstance(JSONObject data) {
		try
		{
			int time=data.getInt("time");
			JSONArray j=data.getJSONArray("info");
			List<Pair<String,Integer>> l=getList(j);
			Event ev= new NewSetContClassEvent(time,l);
			return ev;
		}
		catch(JSONException | EventBuildExcep  e)
		{
			e.printStackTrace();
			return null;
		}
	}
	private List<Pair<String,Integer>> getList(JSONArray j) throws JSONException {
		List<Pair<String,Integer>> l=new ArrayList<Pair<String,Integer>>();
		for(int i=0;i<j.length();i++)
		{
			JSONObject j1=j.getJSONObject(i);
			String name=j1.getString("vehicle");
			int clase=j1.getInt("class");
			Pair<String,Integer> pair=new Pair<String,Integer>(name,clase);
			l.add(pair);
		}
		return l;
	}
}
