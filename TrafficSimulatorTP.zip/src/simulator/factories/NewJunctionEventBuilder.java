package simulator.factories;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import simulator.model.DequeuingStrategy;
import simulator.model.Event;
import simulator.model.LightSwitchingStrategy;
import simulator.model.NewJunctionEvent;


public class NewJunctionEventBuilder extends Builder<Event>{

	private static String name="new_junction";
	private final String time="time";
	private final String id="id";
	private final String coor="coor";
	private final String LsStrategy="ls_strategy";
	private final String DqStrategy="dq_strategy";
	
	private Factory<LightSwitchingStrategy> _LSstr;
	private Factory<DequeuingStrategy> _DSstr;
	
	public NewJunctionEventBuilder(Factory<LightSwitchingStrategy> lssFactory,Factory<DequeuingStrategy> dqsFactory) {
		super(name);
		this._LSstr=lssFactory;
		this._DSstr=dqsFactory;
	}

	@Override
	protected Event createTheInstance(JSONObject data) {
		Event ev=null;
		try {
			JSONArray j2=(JSONArray) data.get(coor);
			
			int x=j2.getInt(0);
			int y=j2.getInt(1);
			
			int time=data.getInt(this.time);
			String id=data.getString(this.id);
			
			JSONObject j1=data.getJSONObject(this.LsStrategy);
			JSONObject j3=data.getJSONObject(this.DqStrategy);
			
			ev= new NewJunctionEvent(time, id, this._LSstr.createInstance(j1), 	this._DSstr.createInstance(j3), x, y);
			
		}
		catch(JSONException e)
		{
			e.printStackTrace();
		}
		return ev;
	}
}
