package Excepciones.Map;

@SuppressWarnings("serial")
public class MapException extends Exception{
	public MapException(String message)
	{	
		super("MapException:\n"+message);
	}
	
	public MapException()
	{
		super();
	}
	
	public MapException(String message,Throwable cause)
	{
		super(message,cause);
	}
	
	public MapException(Throwable cause)
	{
		super(cause);
	}
	
	public MapException(String message, Throwable cause, boolean enableSupression, boolean writeableStackTrace)
	{
		super(message,cause,enableSupression,writeableStackTrace);
	}
}
