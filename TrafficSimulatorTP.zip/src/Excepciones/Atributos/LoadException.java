package Excepciones.Atributos;

@SuppressWarnings("serial")
public class LoadException extends Exception{
	public LoadException() {
		// TODO Auto-generated constructor stub
	}

	public LoadException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LoadException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public LoadException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LoadException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
