package Excepciones.Junction;

@SuppressWarnings("serial")
public class JunctionConstructorException extends Exception{
	public JunctionConstructorException() {
		// TODO Auto-generated constructor stub
	}

	public JunctionConstructorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public JunctionConstructorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public JunctionConstructorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public JunctionConstructorException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
