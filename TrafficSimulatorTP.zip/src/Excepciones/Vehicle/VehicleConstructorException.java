package Excepciones.Vehicle;

@SuppressWarnings("serial")
public class VehicleConstructorException extends Exception{
	public VehicleConstructorException() {
		// TODO Auto-generated constructor stub
	}

	public VehicleConstructorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public VehicleConstructorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public VehicleConstructorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public VehicleConstructorException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
