package Excepciones.Vehicle;

@SuppressWarnings("serial")
public class VehicleContClassException extends Exception{
	public VehicleContClassException() {
		// TODO Auto-generated constructor stub
	}

	public VehicleContClassException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public VehicleContClassException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public VehicleContClassException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public VehicleContClassException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
