package Excepciones.Road;

@SuppressWarnings("serial")
public class RoadConstructorException extends Exception{
	public RoadConstructorException() {
		// TODO Auto-generated constructor stub
	}

	public RoadConstructorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RoadConstructorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public RoadConstructorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RoadConstructorException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
